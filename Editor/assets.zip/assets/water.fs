#version 330 core

// Outputs colors in RGBA
out vec4 FragColor;


uniform vec4 u_TopColor;
uniform vec4 u_BottomColor;
in float level;

void main()
{
	FragColor = mix(u_BottomColor, u_TopColor, level);
}